/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;

import java.util.Date;
import trab1.Consultorio;




/**
 *@author Jose Saravaiva a48540
 * @author bernardo nogueira a47334
 */
public class Main {
    public static void main(String[] args) {
       Consultorio C = new Consultorio();
       
        
        C.addPaciente("Baganha");
        System.out.println("Paciente ");
        C.addPaciente("Andre");
        C.addPaciente("Bernardo");
        C.addPaciente("Vieira");
        C.addPaciente("Diogo");
        
        System.out.println("----------------------------------------------------------------");
        C.addConsulta(new Date(System.currentTimeMillis()), 24.99);
        C.addConsulta(new Date(System.currentTimeMillis()), 11.11);
        C.addConsulta(new Date(System.currentTimeMillis()), 12.30);
        C.addConsulta(new Date(System.currentTimeMillis()), 14.00);
        C.addConsulta(new Date(System.currentTimeMillis()), 15.00);
        
        System.out.println("----------------------------------------------------------------");
        C.addExameMedico(new Date(System.currentTimeMillis()), 29.50, "tipologia");
        C.addExameMedico(new Date(System.currentTimeMillis()), 12, "tipologia");
        C.addExameMedico(new Date(System.currentTimeMillis()), 13, "tipologia");
        C.addExameMedico(new Date(System.currentTimeMillis()), 14, "tipologia");
        C.addExameMedico(new Date(System.currentTimeMillis()), 16, "tipologia");
        
        
        System.out.println("----------------------------------------------------------------");
      
        C.assignServiçoPaciente(0, 1);
        C.assignServiçoPaciente(1, 1);
        C.assignServiçoPaciente(0, 0);
        C.assignServiçoPaciente(1, 0);
        
        System.out.println("----------------------------------------------------------------");
        
        System.out.println("valor total faturado : " + String.format("%.2f€", C.calculaValorRecebido()) + "\n");
        
        C.listarPacientes();
        C.listarServicos();
        






// TODO code application logic here
    }
    
}
