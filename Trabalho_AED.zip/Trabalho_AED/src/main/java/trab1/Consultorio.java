/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trab1;

import java.util.Date;
import java.util.LinkedList;

/**
 *@author Jose Saravaiva a48540
 * @author bernardo nogueira a47334
 */
public class Consultorio {
    private LinkedList< Servico> serviços;
    private LinkedList< Paciente> pacientes;
    
/**
 * 
 */
public Consultorio(){
        serviços = new LinkedList<>();
        pacientes = new LinkedList<>();
    }

/**
 * 
 * @param n
 * @return 
 */
public boolean addPaciente(String n){
      if(pacientes.add(new Paciente(n)));
        return true;
    }
/**
 * 
 * @param dh
 * @param c
 * @return 
 */
public boolean addConsulta(Date dh, double c){
        if(serviços.add(new Servico(dh,c)));
        return true;
    }
/**
 * 
 * @param dh
 * @param c
 * @param t
 * @return 
 */
public boolean addExameMedico(Date dh, double c, String t) {
        if (serviços.add(new ExameMedico(dh, c, t))) {
            return true;
        }
        return false;
}
/**
 * 
 * @param cod
 * @param numid
 * @return 
 */
public boolean assignServiçoPaciente(int cod,int numid){
Servico s= serviços.get(cod);
Paciente p=pacientes.get(numid);
System.out.println("Servico associado:"+s.getCod());
/**
 * 
 */
if (p==null||s==null)return false;
        else return s.assignPaciente(p);

}
/**
 * 
 * @return 
 */
public double calculaValorRecebido(){
double total=0;

 for (int l = 0; l < serviços.size(); l++) {
            Servico s = serviços.get(l);
            total += s.getCusto();
        }

        return total;

}

 public void listarPacientes() {
        System.out.println("Lista dos pacientes: ");
        for (int l = 0; l < pacientes.size(); l++) {
            Paciente p = pacientes.get(l);
            System.out.println("id: " + p.getNumID());
            System.out.println("nome: " + p.getnome());
        }
        System.out.println();
    }
 
 
 public void listarServicos(){
        System.out.println("Lista dos serviços: ");
        for(int l = 0; l < serviços.size(); l++){
            Servico s = serviços.get(l);
            String str = s.getClass().toString();
            str = str.substring(12);
            System.out.println(str);
        }
        System.out.println();
    }


}
