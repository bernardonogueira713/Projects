/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trab1;

import java.util.Date;
/**
 *@author Jose Saravaiva a48540
 * @author bernardo nogueira a47334
 */
public class ExameMedico extends Servico {
private String tipologia;
private Date datahora;
private double custo;

/**
 * 
 * @param dh
 * @param c
 * @param t 
 */
public ExameMedico (Date dh, double c, String t ){
    super(dh,c);    
    tipologia=t;
    }


}

