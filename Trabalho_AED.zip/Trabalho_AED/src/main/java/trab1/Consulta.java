/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trab1;

import java.util.Date;


/**
 *@author Jose Saravaiva a48540
 * @author bernardo nogueira a47334
 */
public class Consulta extends Servico {
    private String diagnostico;
    private Date datahora;
    private double custo;

/**
 * 
 * @param dh
 * @param c 
 */
public Consulta (Date dh, double c){
super(dh,c);
}

/**
 * 
 * @param d 
 */
public void setdiagnostico (String d){
diagnostico=d;
}

}

