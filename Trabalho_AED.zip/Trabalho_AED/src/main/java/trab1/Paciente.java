/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trab1;
/**
 * @author Jose Saravaiva a48540
 * @author bernardo a47334
 */
public class Paciente {
 private static int contador=1;
 private String   nome;
 private int  numid;
 
 /**
  * 
  * @param n 
  */
  public Paciente (String n){
        this.numid=contador++;
      nome = n;
    }
/**
 * 
 * @return 
 */
public String getnome(){
        return nome;
    }


/**
 * 
 * @return 
 */

public int getNumID(){
        return numid;
    }

}

