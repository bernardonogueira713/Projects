/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trab1;

import java.util.Date;
import java.util.LinkedList;
/**
 * @author Jose Saravaiva a48540
 * @author Bernardo Nogueira a47334
 */



public class Servico {
    private static int contador=1;
    private int cod;
    private Date datahora;
    private double custo;
    private LinkedList<Paciente> pacientes;

/**
 * 
 * @param dh
 * @param c 
 */
public Servico (Date dh,double c){
this.cod=contador++;
datahora= dh;
custo=c;
pacientes= new LinkedList<>();
}
/**
 * 
 * @return 
 */
public int getCod(){
return cod;

}
/**
 * 
 * @return 
 */
public Date getDatahora(){
return datahora;

}
/**
 * 
 * @return 
 */
public double getCusto(){
return custo;

}
/**
 * 
 * @param p
 * @return 
 */
public boolean assignPaciente(Paciente p){
if(pacientes.add(p)){
   return true;
}
return false;
}

}
